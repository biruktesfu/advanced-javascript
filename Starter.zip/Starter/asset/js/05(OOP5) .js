//ES6 Person Object 
class Person_ES6 {
    constructor(fName, lName) {
        this.fName = fName;
        this.lName = lName;
    }
    greeting() {
        return `Hello,  ${this.fName} ${this.lName}`;
    }
}

//1. Make Customer class to extend from Person_ES6
class Customer_ES6 {

    constructor(fName, lName) {

        //2. Call the super class [super(fName,lName)]

    }
}

//3. Create Customer ["Jeor", "Mormont"]


//4. Display the greeting on Jeor Customer Object [remove the string when you have the object]
es6_proto.innerHTML = "cu.greeting()";
